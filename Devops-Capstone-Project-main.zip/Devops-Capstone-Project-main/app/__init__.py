"""Task Manager API - DevOps capstone application."""
__version__ = "1.1.0"
